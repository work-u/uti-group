<!--header -->
<header class="header">
	<div class="header-wrapper">
		<a class="logo" href="<?php print $front_page; ?>">
			<img src="<?php print $logo; ?>" height="60px"/>
		</a>
		<div class="menu-principale">
			<nav>
				<ul>
					<li class="blue"><a href="#">Groupe</a></li>
					<li class="blue-ciel"><a href="#">Activités</a></li>
					<li class="vert"><a href="#">Secteurs</a></li>
					<li class="rose"><a href="#">Rejoignez-nous</a></li>
					<li class="mauve"><a href="#">Données<br>financières</a></li>
					<li class="violet"><a href="#">Espace<br>Collaborateurs</a></li>
				</ul>
			</nav>
		</div>
		<div style="clear:both;"></div>
	</div>
</header>
