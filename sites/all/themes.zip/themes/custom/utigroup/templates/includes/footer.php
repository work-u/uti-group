<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!--footer -->
<footer class="footer">
	<div class="footer-wrapper">

	</div>
</footer>